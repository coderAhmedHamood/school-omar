## Module <hr_reward_warning>

#### 28.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial commit for OpenHRMS Official Announcements

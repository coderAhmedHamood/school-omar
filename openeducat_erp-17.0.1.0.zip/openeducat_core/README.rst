This module provide core education management system.
    Features includes managing
        * Student
        * Faculty
        * Course
        * Batch
